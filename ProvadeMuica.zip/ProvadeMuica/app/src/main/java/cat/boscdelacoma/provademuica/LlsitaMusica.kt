//package cat.boscdelacoma.provademuica
//
//import android.Manifest
//import android.annotation.SuppressLint
//import android.content.pm.PackageManager
//import android.media.MediaPlayer
//import android.net.Uri
//import android.os.Bundle
//import android.provider.MediaStore
//import android.widget.ArrayAdapter
//import android.widget.Button
//import android.widget.ImageView
//import android.widget.ListView
//import android.widget.SeekBar
//import android.widget.TextView
//import androidx.appcompat.app.AlertDialog
//import androidx.appcompat.app.AppCompatActivity
//import androidx.core.app.ActivityCompat
//import androidx.core.content.ContextCompat
//
//class LlsitaMusica : AppCompatActivity() {
//    private lateinit var listView: ListView
//    private lateinit var playPauseImageView: ImageView
//    private lateinit var nextImageView: ImageView
//    private lateinit var prevImageView: ImageView
//    private lateinit var stopImageView: ImageView
//    private lateinit var openPopupButton: Button
//    private lateinit var songTitleTextView: TextView
//    private lateinit var seekBar: SeekBar
//
//    private lateinit var songList: MutableList<String>
//    private var mediaPlayer: MediaPlayer? = null
//    private var currentPosition: Int = 0
//
//
//    @SuppressLint("MissingInflatedId")
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_llsita_musica)
//
//        listView = findViewById(R.id.listView)
//        playPauseImageView = findViewById(R.id.playPauseButton)
//        nextImageView = findViewById(R.id.nextButton)
//        prevImageView = findViewById(R.id.prevButton)
//        stopImageView = findViewById(R.id.stopButton)
//        openPopupButton = findViewById(R.id.openPopupButton)
//        seekBar = findViewById(R.id.seekBar)
//
//        if (ContextCompat.checkSelfPermission(
//                this,
//                Manifest.permission.READ_MEDIA_AUDIO
//            ) != PackageManager.PERMISSION_GRANTED
//        ) {
//            ActivityCompat.requestPermissions(
//                this,
//                arrayOf(Manifest.permission.READ_MEDIA_AUDIO),
//                PERMISSION_REQUEST_CODE
//            )
//        } else {
//            loadSongs()
//        }
//
//        mediaPlayer?.setOnCompletionListener {
//            // Restablecer el progreso cuando la canción se completa
//            seekBar.progress = 0
//        }
//
//        mediaPlayer?.setOnPreparedListener {
//            // Configurar el máximo del SeekBar cuando la canción está preparada
//            seekBar.max = mediaPlayer?.duration ?: 0
//        }
//
//        playPauseImageView.setOnClickListener { togglePlayPause() }
//        nextImageView.setOnClickListener { playNextSong() }
//        prevImageView.setOnClickListener { playPreviousSong() }
//        stopImageView.setOnClickListener { stopAllSongs() }
//        openPopupButton.setOnClickListener { loadSongs() }
//
//        listView.setOnItemClickListener { _, _, position, _ ->
//            handleSongSelection(position)
//        }
//    }
//
//    private fun loadSongs() {
//        songList = mutableListOf()
//
//        contentResolver.query(
//            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
//            null,
//            null,
//            null,
//            null
//        )?.use { c ->
//            val titleColumn = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
//            while (c.moveToNext()) {
//                songList.add(c.getString(titleColumn))
//            }
//        }
//
//        val popupView = layoutInflater.inflate(R.layout.popup_song_list, null)
//        val popupListView = popupView.findViewById<ListView>(R.id.popupListView)
//        popupListView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, songList)
//
//        val alertDialogBuilder = AlertDialog.Builder(this)
//            .setView(popupView)
//            .setTitle("Lista de Canciones")
//            .setCancelable(true)
//
//        val alertDialog = alertDialogBuilder.create()
//        alertDialog.show()
//
//        popupListView.setOnItemClickListener { _, _, position, _ ->
//            handleSongSelection(position)
//            alertDialog.dismiss()
//        }
//    }
//
//    private fun togglePlayPause() {
//        mediaPlayer?.let {
//            if (it.isPlaying) {
//                it.pause()
//                playPauseImageView.setImageResource(R.drawable.plays)
//            } else {
//                it.start()
//                playPauseImageView.setImageResource(R.drawable.pauses)
//            }
//        }
//    }
//
//    @SuppressLint("Range")
//    private fun getSongUri(songTitle: String): Uri? {
//        contentResolver.query(
//            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
//            null,
//            MediaStore.Audio.Media.TITLE + "=?",
//            arrayOf(songTitle),
//            null
//        )?.use { cursor ->
//            if (cursor.moveToFirst()) {
//                return Uri.parse(cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA)))
//            }
//        }
//        return null
//    }
//
//    private fun playNextSong() {
//        releaseMediaPlayer()
//        currentPosition = (currentPosition + 1) % songList.size
//        handleSongSelection(currentPosition)
//    }
//
//    private fun playPreviousSong() {
//        releaseMediaPlayer()
//        currentPosition = (currentPosition - 1 + songList.size) % songList.size
//        handleSongSelection(currentPosition)
//    }
//
//    private fun stopAllSongs() {
//        releaseMediaPlayer()
//        playPauseImageView.setImageResource(R.drawable.plays)
//    }
//
//    private fun handleSongSelection(position: Int) {
//        releaseMediaPlayer()
//        playSongAtIndex(position)
//    }
//
//    private fun playSongAtIndex(position: Int) {
//        relaseMediaPlayer()
//        val songTitle = songList[position]
//        val songUri = getSongUri(songTitle)
//
//        mediaPlayer = MediaPlayer().apply {
//            songUri?.let {
//                setDataSource(this@LlsitaMusica, it)
//                prepare()
//                start()
//                listView.setItemChecked(position, true)
//                playPauseImageView.setImageResource(R.drawable.pauses)
//
//                val words = songTitle.split(" ")
//                val abbreviatedTitle = if (words.size >= 2) {
//                    "${words[0]} ${words[1]}"
//                } else {
//                    songTitle
//                }
//                updateSongTitle(abbreviatedTitle)
//
//                seekBar.max = duration
//                Thread {
//                    while (isPlaying) {
//                        runOnUiThread {
//                            seekBar.progress = currentPosition
//                        }
//                        try {
//                            Thread.sleep(1000)
//                        } catch (e: InterruptedException) {
//                            e.printStackTrace()
//                        }
//                    }
//                }.start()
//
//                seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
//                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
//                        if (fromUser && mediaPlayer != null) {
//                            try {
//                                mediaPlayer?.seekTo(progress)
//                            } catch (e: Exception) {
//                                e.printStackTrace()
//                            }
//                        }
//                    }
//
//                    override fun onStartTrackingTouch(seekBar: SeekBar?) {
//                    }
//
//                    override fun onStopTrackingTouch(seekBar: SeekBar?) {
//                    }
//                })
//            }
//        }
//    }
//
//    private fun relaseMediaPlayer() {
//        mediaPlayer?.apply {
//            stop()
//            reset()
//            release()
//        }
//        mediaPlayer = null
//    }
//
//    private fun updateSongTitle(title: String) {
//        songTitleTextView = findViewById(R.id.nomCancion)
//        songTitleTextView.text = title
//    }
//
//    private fun releaseMediaPlayer() {
//        mediaPlayer?.apply {
//            stop()
//            reset()
//            release()
//        }
//        mediaPlayer = null
//    }
//
//    override fun onDestroy() {
//        super.onDestroy()
//        releaseMediaPlayer()
//    }
//
//    companion object {
//        private const val PERMISSION_REQUEST_CODE = 123
//    }
//}